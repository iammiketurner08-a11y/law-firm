# The Law Firm of Tejan-Jalloh & Fode M Dabor — Website

A responsive, static website package created from the approved UI direction.

## Contents

- `index.html` — complete one-page website
- `assets/css/styles.css` — responsive styling
- `assets/js/main.js` — mobile menu and consultation modal interactions
- `assets/images/logo.png` — supplied firm logo

## Use

Open `index.html` in a browser for a local preview. To publish, upload the contents of this folder to the website's public directory (for example, `public_html`).

## Before publishing

- Replace the demonstration address, phone number and email address with verified firm information.
- Connect the consultation form to a secure form handler or CRM.
- Review and complete the Privacy Policy, Terms of Use and Disclaimer pages.
- Confirm all practice areas and claims with the firm.

The layout uses externally hosted Unsplash images as stock-image placeholders. Replace them with appropriately licensed final imagery if required.
